package mundo1;

import java.util.List;

public class Comerciante {
    private String nomeComerciante;
    private List<Transacao> transacoes;

    public Comerciante(String nomeComerciante) {
        this.nomeComerciante = nomeComerciante;
    }

    // Getters e setters para os atributos

    public String getNomeComerciante() {
        return nomeComerciante;
    }

    public void setNomeComerciante(String nomeComerciante) {
        this.nomeComerciante = nomeComerciante;
    }

    public List<Transacao> getTransacoes() {
        return transacoes;
    }

    public void setTransacoes(List<Transacao> transacoes) {
        this.transacoes = transacoes;
    }
}
