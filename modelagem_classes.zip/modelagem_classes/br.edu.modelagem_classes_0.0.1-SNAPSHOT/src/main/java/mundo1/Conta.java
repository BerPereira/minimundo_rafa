package mundo1;

public class Conta {
    private int id;
    private PessoaFisica pessoaFisica;
    private CartaoCredito cartaoCredito;

    public Conta(int id, PessoaFisica pessoaFisica, CartaoCredito cartaoCredito) {
        this.id = id;
        this.pessoaFisica = pessoaFisica;
        this.cartaoCredito = cartaoCredito;
    }

    // Getters e setters para os atributos

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public PessoaFisica getPessoaFisica() {
        return pessoaFisica;
    }

    public void setPessoaFisica(PessoaFisica pessoaFisica) {
        this.pessoaFisica = pessoaFisica;
    }

    public CartaoCredito getCartaoCredito() {
        return cartaoCredito;
    }

    public void setCartaoCredito(CartaoCredito cartaoCredito) {
        this.cartaoCredito = cartaoCredito;
    }
}
