package mundo1;

import java.util.Date;

public class Transacao {
    private float valor;
    private Date horaCompra;
    private Comerciante comerciante;
    private String autorizacao;

    public Transacao(float valor, Date horaCompra, Comerciante comerciante, String autorizacao) {
        this.valor = valor;
        this.horaCompra = horaCompra;
        this.comerciante = comerciante;
        this.autorizacao = autorizacao;
    }

    // Getters e setters para os atributos

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public Date getHoraCompra() {
        return horaCompra;
    }

    public void setHoraCompra(Date horaCompra) {
        this.horaCompra = horaCompra;
    }

    public Comerciante getComerciante() {
        return comerciante;
    }

    public void setComerciante(Comerciante comerciante) {
        this.comerciante = comerciante;
    }

    public String getAutorizacao() {
        return autorizacao;
    }

    public void setAutorizacao(String autorizacao) {
        this.autorizacao = autorizacao;
    }
}
