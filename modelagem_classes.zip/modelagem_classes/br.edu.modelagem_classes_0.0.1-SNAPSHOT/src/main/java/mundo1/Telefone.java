package mundo1;

public class Telefone {
    private int codigo;
    private int ddd;
    private String numeroTelefone;

    public Telefone(int codigo, int ddd, String numeroTelefone) {
        this.codigo = codigo;
        this.ddd = ddd;
        this.numeroTelefone = numeroTelefone;
    }

    // Getters e setters para os atributos

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getDdd() {
        return ddd;
    }

    public void setDdd(int ddd) {
        this.ddd = ddd;
    }

    public String getNumeroTelefone() {
        return numeroTelefone;
    }

    public void setNumeroTelefone(String numeroTelefone) {
        this.numeroTelefone = numeroTelefone;
    }
}
