
package mundo1;

import java.util.Date;
import java.util.List;

public class CartaoCredito {
    private String numeroCartao;
    private int codigoSeguranca;
    private Date validade;
    private float limiteDisponivel;
    private boolean cartaoAtivo;
    private Date ultimaCompra;
    private List<Transacao> transacoes;

    public CartaoCredito(String numeroCartao, int codigoSeguranca, Date validade, float limiteDisponivel, boolean cartaoAtivo, Date ultimaCompra) {
        this.numeroCartao = numeroCartao;
        this.codigoSeguranca = codigoSeguranca;
        this.validade = validade;
        this.limiteDisponivel = limiteDisponivel;
        this.cartaoAtivo = cartaoAtivo;
        this.ultimaCompra = ultimaCompra;
    }

    // Getters e setters para os atributos

    public String getNumeroCartao() {
        return numeroCartao;
    }

    public void setNumeroCartao(String numeroCartao) {
        this.numeroCartao = numeroCartao;
    }

    public int getCodigoSeguranca() {
        return codigoSeguranca;
    }

    public void setCodigoSeguranca(int codigoSeguranca) {
        this.codigoSeguranca = codigoSeguranca;
    }

    public Date getValidade() {
        return validade;
    }

    public void setValidade(Date validade) {
        this.validade = validade;
    }

    public float getLimiteDisponivel() {
        return limiteDisponivel;
    }

    public void setLimiteDisponivel(float limiteDisponivel) {
        this.limiteDisponivel = limiteDisponivel;
    }

    public boolean isCartaoAtivo() {
        return cartaoAtivo;
    }

    public void setCartaoAtivo(boolean cartaoAtivo) {
        this.cartaoAtivo = cartaoAtivo;
    }

    public Date getUltimaCompra() {
        return ultimaCompra;
    }

    public void setUltimaCompra(Date ultimaCompra) {
        this.ultimaCompra = ultimaCompra;
    }

    public List<Transacao> getTransacoes() {
        return transacoes;
    }

    public void setTransacoes(List<Transacao> transacoes) {
        this.transacoes = transacoes;
    }
}
