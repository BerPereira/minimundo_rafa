package mundo2;

import java.util.List;

public class Musica {
    private float duracao;
    private String nomeMusica;
    private Banda banda;
    private Album album;
    private String genero;
    private List<Playlist> playlists;

    public Musica(float duracao, String nomeMusica, Banda banda, Album album, String genero, List<Playlist> playlists) {
        this.duracao = duracao;
        this.nomeMusica = nomeMusica;
        this.banda = banda;
        this.album = album;
        this.genero = genero;
        this.playlists = playlists;
    }

    // Getters e setters para os atributos

    public float getDuracao() {
        return duracao;
    }

    public void setDuracao(float duracao) {
        this.duracao = duracao;
    }

    public String getNomeMusica() {
        return nomeMusica;
    }

    public void setNomeMusica(String nomeMusica) {
        this.nomeMusica = nomeMusica;
    }

    public Banda getBanda() {
        return banda;
    }

    public void setBanda(Banda banda) {
        this.banda = banda;
    }

    public Album getAlbum() {
        return album;
    }

    public void setAlbum(Album album) {
        this.album = album;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public List<Playlist> getPlaylists() {
        return playlists;
    }

    public void setPlaylists(List<Playlist> playlists) {
        this.playlists = playlists;
    }
}
