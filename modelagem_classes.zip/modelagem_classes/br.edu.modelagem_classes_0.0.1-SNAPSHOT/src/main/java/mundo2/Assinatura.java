package mundo2;

import java.util.List;
import mundo1.CartaoCredito;

public class Assinatura {
    private List<Plano> planos;
    private List<Usuario> usuarios;
    private boolean ativa;
    private CartaoCredito cartao;

    public Assinatura(List<Plano> planos, List<Usuario> usuarios, boolean ativa, CartaoCredito cartao) {
        this.planos = planos;
        this.usuarios = usuarios;
        this.ativa = ativa;
        this.cartao = cartao;
    }

    // Getters e setters para os atributos

    public List<Plano> getPlanos() {
        return planos;
    }

    public void setPlanos(List<Plano> planos) {
        this.planos = planos;
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(List<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    public boolean isAtiva() {
        return ativa;
    }

    public void setAtiva(boolean ativa) {
        this.ativa = ativa;
    }

    public CartaoCredito getCartao() {
        return cartao;
    }

    public void setCartao(CartaoCredito cartao) {
        this.cartao = cartao;
    }
}
