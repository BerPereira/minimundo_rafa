package mundo2;

import java.util.List;

public class Plano {
    private String nomePlano;
    private float valor;
    private List<Assinatura> assinaturas;

    public Plano(String nomePlano, float valor, List<Assinatura> assinaturas) {
        this.nomePlano = nomePlano;
        this.valor = valor;
        this.assinaturas = assinaturas;
    }

    // Getters e setters para os atributos

    public String getNomePlano() {
        return nomePlano;
    }

    public void setNomePlano(String nomePlano) {
        this.nomePlano = nomePlano;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public List<Assinatura> getAssinaturas() {
        return assinaturas;
    }

    public void setAssinaturas(List<Assinatura> assinaturas) {
        this.assinaturas = assinaturas;
    }
}
