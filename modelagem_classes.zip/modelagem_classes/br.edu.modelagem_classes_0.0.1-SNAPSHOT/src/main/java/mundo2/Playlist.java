package mundo2;

import java.util.List;

public class Playlist {
    private String nomePlaylist;
    private List<Musica> musicas;
    private Usuario usuario;

    public Playlist(String nomePlaylist, List<Musica> musicas, Usuario usuario) {
        this.nomePlaylist = nomePlaylist;
        this.musicas = musicas;
        this.usuario = usuario;
    }

    // Getters e setters para os atributos

    public String getNomePlaylist() {
        return nomePlaylist;
    }

    public void setNomePlaylist(String nomePlaylist) {
        this.nomePlaylist = nomePlaylist;
    }

    public List<Musica> getMusicas() {
        return musicas;
    }

    public void setMusicas(List<Musica> musicas) {
        this.musicas = musicas;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
}
