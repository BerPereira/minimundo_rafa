package mundo2;

import java.util.List;

public class Banda {
    private String nomeBanda;
    private List<Album> albuns;
    private List<Musica> musicas;
    private String genero;

    public Banda(String nomeBanda, List<Album> albuns, List<Musica> musicas, String genero) {
        this.nomeBanda = nomeBanda;
        this.albuns = albuns;
        this.musicas = musicas;
        this.genero = genero;
    }

    // Getters e setters para os atributos

    public String getNomeBanda() {
        return nomeBanda;
    }

    public void setNomeBanda(String nomeBanda) {
        this.nomeBanda = nomeBanda;
    }

    public List<Album> getAlbuns() {
        return albuns;
    }

    public void setAlbuns(List<Album> albuns) {
        this.albuns = albuns;
    }

    public List<Musica> getMusicas() {
        return musicas;
    }

    public void setMusicas(List<Musica> musicas) {
        this.musicas = musicas;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }
}
