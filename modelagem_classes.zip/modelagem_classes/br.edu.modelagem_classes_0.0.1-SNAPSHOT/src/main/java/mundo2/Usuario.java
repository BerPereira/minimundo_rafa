package mundo2;

import java.util.List;

public class Usuario {
    private String nomeUsuario;
    private String sobrenome;
    private List<Assinatura> assinaturas;
    private List<Playlist> playlists;
    private List<Banda> bandasFavoritas;
    private List<Album> albunsFavoritos;
    private List<Musica> musicasFavoritas;

    public Usuario(String nomeUsuario, String sobrenome, List<Assinatura> assinaturas, List<Playlist> playlists, List<Banda> bandasFavoritas, List<Album> albunsFavoritos, List<Musica> musicasFavoritas) {
        this.nomeUsuario = nomeUsuario;
        this.sobrenome = sobrenome;
        this.assinaturas = assinaturas;
        this.playlists = playlists;
        this.bandasFavoritas = bandasFavoritas;
        this.albunsFavoritos = albunsFavoritos;
        this.musicasFavoritas = musicasFavoritas;
    }

    // Getters e setters para os atributos

    public String getNomeUsuario() {
        return nomeUsuario;
    }

    public void setNomeUsuario(String nomeUsuario) {
        this.nomeUsuario = nomeUsuario;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public List<Assinatura> getAssinaturas() {
        return assinaturas;
    }

    public void setAssinaturas(List<Assinatura> assinaturas) {
        this.assinaturas = assinaturas;
    }

    public List<Playlist> getPlaylists() {
        return playlists;
    }

    public void setPlaylists(List<Playlist> playlists) {
        this.playlists = playlists;
    }

    public List<Banda> getBandasFavoritas() {
        return bandasFavoritas;
    }

    public void setBandasFavoritas(List<Banda> bandasFavoritas) {
        this.bandasFavoritas = bandasFavoritas;
    }

    public List<Album> getAlbunsFavoritos() {
        return albunsFavoritos;
    }

    public void setAlbunsFavoritos(List<Album> albunsFavoritos) {
        this.albunsFavoritos = albunsFavoritos;
    }

    public List<Musica> getMusicasFavoritas() {
        return musicasFavoritas;
    }

    public void setMusicasFavoritas(List<Musica> musicasFavoritas) {
        this.musicasFavoritas = musicasFavoritas;
    }
}
