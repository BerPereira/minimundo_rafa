package mundo2;

import java.util.List;

public class Album {
    private String nomeAlbum;
    private Banda banda;
    private List<Musica> musicas;
    private String genero;

    public Album(String nomeAlbum, Banda banda, List<Musica> musicas, String genero) {
        this.nomeAlbum = nomeAlbum;
        this.banda = banda;
        this.musicas = musicas;
        this.genero = genero;
    }

    // Getters e setters para os atributos

    public String getNomeAlbum() {
        return nomeAlbum;
    }

    public void setNomeAlbum(String nomeAlbum) {
        this.nomeAlbum = nomeAlbum;
    }

    public Banda getBanda() {
        return banda;
    }

    public void setBanda(Banda banda) {
        this.banda = banda;
    }

    public List<Musica> getMusicas() {
        return musicas;
    }

    public void setMusicas(List<Musica> musicas) {
        this.musicas = musicas;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }
}
